﻿Public Class Form1

    Public Property zahl As String = ""
    Public Property calc As String = ""
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles b1.Click

        TextBox1.Text += "1"
    End Sub

    Private Sub b3_Click(sender As Object, e As EventArgs) Handles b3.Click
        TextBox1.Text += "3"
    End Sub

    Private Sub b2_Click(sender As Object, e As EventArgs) Handles b2.Click
        TextBox1.Text += "2"
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub b4_Click(sender As Object, e As EventArgs) Handles b4.Click
        TextBox1.Text += "4"
    End Sub

    Private Sub b5_Click(sender As Object, e As EventArgs) Handles b5.Click
        TextBox1.Text += "5"
    End Sub

    Private Sub b6_Click(sender As Object, e As EventArgs) Handles b6.Click
        TextBox1.Text += "6"
    End Sub

    Private Sub b7_Click(sender As Object, e As EventArgs) Handles b7.Click
        TextBox1.Text += "7"
    End Sub

    Private Sub b8_Click(sender As Object, e As EventArgs) Handles b8.Click
        TextBox1.Text += "8"
    End Sub

    Private Sub b9_Click(sender As Object, e As EventArgs) Handles b9.Click
        TextBox1.Text += "9"
    End Sub

    Private Sub b0_Click(sender As Object, e As EventArgs) Handles b0.Click
        TextBox1.Text += "0"
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        If (TextBox1.Text.Length > 0) Then
            TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.Length - 1)
        End If
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click

        calc = ""
        zahl = ""
        TextBox1.Text = ""
        Label2.Text = ""
        Label1.Text = ""

    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles bsolve.Click

        If (calc = "+") Then
            TextBox1.Text = Val(zahl) + Val(TextBox1.Text)
        End If
        If (calc = "-") Then
            TextBox1.Text = Val(zahl) - Val(TextBox1.Text)
        End If
        If (calc = "*") Then
            TextBox1.Text = Val(zahl) * Val(TextBox1.Text)
        End If
        If (calc = "/") Then
            TextBox1.Text = Val(zahl) / Val(TextBox1.Text)
        End If

        Label1.Text = ""
        Label2.Text = ""

    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        zahl = TextBox1.Text
        Label1.Text = zahl
        TextBox1.Text = ""

        calc = "/"
        Label2.Text = calc
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        zahl = TextBox1.Text
        Label1.Text = zahl
        TextBox1.Text = ""

        calc = "+"
        Label2.Text = calc
    End Sub

    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        zahl = TextBox1.Text
        Label1.Text = zahl
        TextBox1.Text = ""

        calc = "-"
        Label2.Text = calc
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        zahl = TextBox1.Text
        Label1.Text = zahl
        TextBox1.Text = ""

        calc = "*"
        Label2.Text = calc
    End Sub

    Private Sub bPunkt_Click(sender As Object, e As EventArgs) Handles bPunkt.Click
        TextBox1.Text += "."
    End Sub

    Private Sub bround_Click(sender As Object, e As EventArgs) Handles bround.Click
        TextBox1.Text = Math.Round(Val(TextBox1.Text))
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TextBox1.Text = 1.0 / Val(TextBox1.Text)
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox1.Text = Math.PI
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = Math.E
    End Sub
End Class
